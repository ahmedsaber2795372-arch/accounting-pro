
import React, { useState } from 'react';
import { Reminder, Account } from '../types';

interface RemindersProps {
  reminders: Reminder[];
  accounts: Account[];
  onAdd: (reminder: Reminder) => void;
  onDelete: (id: string) => void;
  onToggleStatus: (id: string) => void;
  currencySymbol: string;
}

const Reminders: React.FC<RemindersProps> = ({ reminders, accounts, onAdd, onDelete, onToggleStatus, currencySymbol }) => {
  const [showModal, setShowModal] = useState(false);
  const [formData, setFormData] = useState<Partial<Reminder>>({
    title: '',
    amount: 0,
    dueDate: new Date().toISOString().split('T')[0],
    type: 'payable',
    status: 'pending'
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title || !formData.amount) return;

    onAdd({
      id: Math.random().toString(36).substr(2, 9),
      title: formData.title!,
      amount: Number(formData.amount),
      dueDate: formData.dueDate!,
      accountId: formData.accountId,
      type: formData.type as any,
      status: 'pending'
    });
    setShowModal(false);
    setFormData({ title: '', amount: 0, dueDate: new Date().toISOString().split('T')[0], type: 'payable' });
  };

  const getStatusColor = (dueDate: string, status: string) => {
    if (status === 'paid') return 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400';
    const today = new Date().toISOString().split('T')[0];
    if (dueDate < today) return 'bg-rose-100 text-rose-700 dark:bg-rose-900/30 dark:text-rose-400';
    if (dueDate === today) return 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400';
    return 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400';
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="flex justify-between items-center bg-white dark:bg-slate-900 p-6 rounded-3xl shadow-sm border border-slate-100 dark:border-slate-800">
        <div>
          <h3 className="text-xl font-black text-slate-800 dark:text-white">إدارة تنبيهات المدفوعات</h3>
          <p className="text-sm text-slate-400">تابع التزاماتك المالية وتحصيلاتك القادمة</p>
        </div>
        <button 
          onClick={() => setShowModal(true)}
          className="bg-emerald-600 hover:bg-emerald-700 text-white px-6 py-3 rounded-2xl font-black text-sm transition shadow-lg shadow-emerald-900/10 flex items-center gap-2"
        >
          <span>🔔</span> إضافة تنبيه جديد
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {reminders.length === 0 ? (
          <div className="col-span-full py-20 text-center bg-slate-50 dark:bg-slate-900/50 rounded-[2rem] border-2 border-dashed border-slate-200 dark:border-slate-800">
            <div className="text-4xl mb-4">📭</div>
            <p className="text-slate-500 font-bold">لا توجد تنبيهات مجدولة حالياً</p>
          </div>
        ) : (
          reminders.map((reminder) => (
            <div key={reminder.id} className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm hover:shadow-md transition group">
              <div className="flex justify-between items-start mb-4">
                <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest ${getStatusColor(reminder.dueDate, reminder.status)}`}>
                  {reminder.status === 'paid' ? 'تم السداد' : (reminder.dueDate < new Date().toISOString().split('T')[0] ? 'متأخر' : 'قادم')}
                </span>
                <button onClick={() => onDelete(reminder.id)} className="text-slate-300 hover:text-rose-500 transition opacity-0 group-hover:opacity-100">🗑️</button>
              </div>
              <h4 className="text-lg font-black text-slate-800 dark:text-white mb-2">{reminder.title}</h4>
              <div className="flex items-center gap-2 text-slate-400 text-sm mb-4">
                <span>📅</span> {reminder.dueDate}
              </div>
              <div className="flex justify-between items-end border-t dark:border-slate-800 pt-4 mt-4">
                <div>
                  <p className="text-[10px] text-slate-400 font-bold uppercase">المبلغ المطلوب</p>
                  <p className="text-xl font-black text-slate-800 dark:text-white">
                    {reminder.amount.toLocaleString()} <span className="text-xs text-slate-400">{currencySymbol}</span>
                  </p>
                </div>
                {reminder.status === 'pending' && (
                  <button 
                    onClick={() => onToggleStatus(reminder.id)}
                    className="bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-900/20 text-emerald-600 dark:text-emerald-400 px-4 py-2 rounded-xl text-xs font-black transition"
                  >
                    تحديد كمدفوع ✓
                  </button>
                )}
              </div>
            </div>
          ))
        )}
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-slate-900 rounded-[2.5rem] p-8 w-full max-w-lg shadow-2xl border border-white/10">
            <h3 className="text-2xl font-black mb-8 text-slate-800 dark:text-white flex items-center gap-3">
              <span>🔔</span> جدولة تنبيه مالي
            </h3>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-2">وصف التنبيه / الدفعة</label>
                <input 
                  type="text" required
                  className="w-full px-5 py-4 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl outline-none text-slate-800 dark:text-white font-bold"
                  value={formData.title}
                  onChange={e => setFormData({...formData, title: e.target.value})}
                  placeholder="مثال: فاتورة كهرباء شهر يناير"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-2">المبلغ</label>
                  <input 
                    type="number" required
                    className="w-full px-5 py-4 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl outline-none text-slate-800 dark:text-white font-bold"
                    value={formData.amount}
                    onChange={e => setFormData({...formData, amount: Number(e.target.value)})}
                  />
                </div>
                <div>
                  <label className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-2">تاريخ الاستحقاق</label>
                  <input 
                    type="date" required
                    className="w-full px-5 py-4 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl outline-none text-slate-800 dark:text-white font-bold"
                    value={formData.dueDate}
                    onChange={e => setFormData({...formData, dueDate: e.target.value})}
                  />
                </div>
              </div>
              <div>
                <label className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-2">ارتباط بحساب (اختياري)</label>
                <select 
                  className="w-full px-5 py-4 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl outline-none text-slate-800 dark:text-white font-bold"
                  value={formData.accountId}
                  onChange={e => setFormData({...formData, accountId: e.target.value})}
                >
                  <option value="">عام - غير مرتبط بحساب</option>
                  {accounts.map(a => <option key={a.id} value={a.id}>{a.name} ({a.code})</option>)}
                </select>
              </div>
              <div className="flex justify-end gap-3 pt-4 border-t dark:border-slate-800">
                <button type="button" onClick={() => setShowModal(false)} className="px-6 py-4 text-slate-400 font-bold hover:bg-slate-50 dark:hover:bg-slate-800 rounded-2xl transition">إلغاء</button>
                <button type="submit" className="px-8 py-4 bg-emerald-600 text-white rounded-2xl font-black shadow-lg shadow-emerald-900/10 hover:bg-emerald-700 transition">تفعيل التنبيه</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Reminders;
