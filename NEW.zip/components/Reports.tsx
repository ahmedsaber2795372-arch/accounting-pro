
import React, { useState } from 'react';
import { Account, AccountType, JournalEntry, InventoryItem } from '../types';

interface ReportsProps {
  accounts: Account[];
  entries: JournalEntry[];
  inventory: InventoryItem[];
  type: 'income' | 'balance' | 'inventory';
  currencySymbol: string;
  companyName: string;
  language: 'ar' | 'en';
}

const Reports: React.FC<ReportsProps> = ({ accounts, entries, inventory, type, currencySymbol, companyName, language }) => {
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [isCompareMode, setIsCompareMode] = useState(false);
  const [prevStartDate, setPrevStartDate] = useState('');
  const [prevEndDate, setPrevEndDate] = useState('');
  const [inventoryCategory, setInventoryCategory] = useState('الكل');

  const handlePrint = () => {
    window.print();
  };

  const getBalanceInRange = (accountId: string, normalType: 'debit' | 'credit', s: string, e: string) => {
    return entries
      .filter(entry => {
        if (!s && !e) return true;
        const entryDate = entry.date;
        const start = s || '1970-01-01';
        const end = e || '2099-12-31';
        return entryDate >= start && entryDate <= end;
      })
      .reduce((total, entry) => {
        const item = entry.items.find(i => i.accountId === accountId);
        if (!item) return total;
        return normalType === 'debit' 
          ? total + (item.debit - item.credit) 
          : total + (item.credit - item.debit);
      }, 0);
  };

  const calculateChange = (current: number, previous: number) => {
    const diff = current - previous;
    const percent = previous !== 0 ? (diff / Math.abs(previous)) * 100 : 0;
    return { diff, percent };
  };

  const renderIncomeStatement = () => {
    const incomeAccounts = accounts.filter(a => a.type === AccountType.INCOME);
    const expenseAccounts = accounts.filter(a => a.type === AccountType.EXPENSE);
    
    const mappedAccounts = [...incomeAccounts, ...expenseAccounts].map(acc => {
      const current = getBalanceInRange(acc.id, (acc.type === AccountType.EXPENSE ? 'debit' : 'credit'), startDate, endDate);
      const previous = isCompareMode ? getBalanceInRange(acc.id, (acc.type === AccountType.EXPENSE ? 'debit' : 'credit'), prevStartDate, prevEndDate) : 0;
      const { diff, percent } = calculateChange(current, previous);
      return { ...acc, current, previous, diff, percent };
    });

    const totalIncomeCurrent = mappedAccounts.filter(a => a.type === AccountType.INCOME).reduce((s, a) => s + a.current, 0);
    const totalIncomePrev = mappedAccounts.filter(a => a.type === AccountType.INCOME).reduce((s, a) => s + a.previous, 0);
    const incomeStats = calculateChange(totalIncomeCurrent, totalIncomePrev);

    const cogsAccounts = mappedAccounts.filter(a => a.code === '5202' || a.name.includes('تكلفة البضاعة'));
    const totalCogsCurrent = cogsAccounts.reduce((s, a) => s + a.current, 0);
    const totalCogsPrev = cogsAccounts.reduce((s, a) => s + a.previous, 0);
    
    const grossProfitCurrent = totalIncomeCurrent - totalCogsCurrent;
    const grossProfitPrev = totalIncomePrev - totalCogsPrev;
    const grossProfitStats = calculateChange(grossProfitCurrent, grossProfitPrev);

    const otherExpenses = mappedAccounts.filter(a => a.type === AccountType.EXPENSE && !cogsAccounts.find(c => c.id === a.id));
    const totalExpCurrent = otherExpenses.reduce((s, a) => s + a.current, 0);
    const totalExpPrev = otherExpenses.reduce((s, a) => s + a.previous, 0);
    const expStats = calculateChange(totalExpCurrent, totalExpPrev);

    const netProfitCurrent = grossProfitCurrent - totalExpCurrent;
    const netProfitPrev = grossProfitPrev - totalExpPrev;
    const netProfitStats = calculateChange(netProfitCurrent, netProfitPrev);

    return (
      <div className="space-y-6">
        {/* Filters Panel */}
        <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-800 space-y-4 print:hidden">
          <div className="flex flex-wrap gap-6 items-end">
            <div className="space-y-2">
              <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">الفترة الحالية (من - إلى)</label>
              <div className="flex gap-2">
                <input type="date" className="px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg text-sm dark:text-white outline-none focus:ring-2 focus:ring-emerald-500" value={startDate} onChange={e => setStartDate(e.target.value)} />
                <input type="date" className="px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg text-sm dark:text-white outline-none focus:ring-2 focus:ring-emerald-500" value={endDate} onChange={e => setEndDate(e.target.value)} />
              </div>
            </div>

            <div className="flex items-center gap-3 h-[42px]">
              <label className="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" className="sr-only peer" checked={isCompareMode} onChange={() => setIsCompareMode(!isCompareMode)} />
                <div className="w-11 h-6 bg-slate-200 dark:bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
                <span className="mr-3 text-sm font-bold text-slate-600 dark:text-slate-400">تفعيل وضع المقارنة</span>
              </label>
            </div>

            {isCompareMode && (
              <div className="space-y-2 animate-in slide-in-from-right-4 duration-300">
                <label className="block text-xs font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider">فترة المقارنة (السابقة)</label>
                <div className="flex gap-2">
                  <input type="date" className="px-3 py-2 bg-emerald-50/50 dark:bg-emerald-900/10 border border-emerald-100 dark:border-emerald-800 rounded-lg text-sm dark:text-white outline-none" value={prevStartDate} onChange={e => setPrevStartDate(e.target.value)} />
                  <input type="date" className="px-3 py-2 bg-emerald-50/50 dark:bg-emerald-900/10 border border-emerald-100 dark:border-emerald-800 rounded-lg text-sm dark:text-white outline-none" value={prevEndDate} onChange={e => setPrevEndDate(e.target.value)} />
                </div>
              </div>
            )}
            
            <div className="flex-1 flex justify-end gap-3">
              <button onClick={handlePrint} className="bg-slate-900 dark:bg-emerald-600 text-white px-6 py-2 rounded-xl text-sm font-bold shadow-lg flex items-center gap-2 transition hover:opacity-90 active:scale-95"><span>📄</span> طباعة التقرير</button>
            </div>
          </div>
        </div>

        {/* Report Content */}
        <div className="bg-white dark:bg-slate-900 p-8 lg:p-12 rounded-[2.5rem] shadow-sm border border-slate-100 dark:border-slate-800 max-w-6xl mx-auto print:shadow-none print:border-none print:bg-white print:p-0 print:text-black">
          <div className="text-center mb-12 border-b-4 border-slate-900 dark:border-slate-800 pb-8">
            <h4 className="text-emerald-600 font-black text-xl mb-2">{companyName}</h4>
            <h2 className="text-3xl font-black text-slate-800 dark:text-white">قائمة الدخل المقارنة</h2>
            <div className="flex flex-wrap justify-center gap-4 mt-6 text-xs font-bold">
               <span className="bg-slate-100 dark:bg-slate-800 px-4 py-2 rounded-full text-slate-600 dark:text-slate-400">الفترة أ: {startDate || 'الكل'} ← {endDate || 'الآن'}</span>
               {isCompareMode && <span className="bg-emerald-50 dark:bg-emerald-900/20 px-4 py-2 rounded-full border border-emerald-100 dark:border-emerald-800 text-emerald-700 dark:text-emerald-400">الفترة ب (المقارنة): {prevStartDate} ← {prevEndDate}</span>}
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-right border-collapse">
              <thead>
                <tr className="text-slate-400 text-[10px] font-black uppercase tracking-widest border-b-2 border-slate-200 dark:border-slate-800">
                  <th className="py-4 px-2">الحساب</th>
                  <th className="py-4 px-2 text-left">الفترة الحالية ({currencySymbol})</th>
                  {isCompareMode && (
                    <>
                      <th className="py-4 px-2 text-left text-slate-500">الفترة السابقة</th>
                      <th className="py-4 px-2 text-left">التغير (المبلغ)</th>
                      <th className="py-4 px-2 text-left">التغير (%)</th>
                    </>
                  )}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50 dark:divide-slate-800/50">
                {/* Income Section */}
                <tr><td colSpan={isCompareMode ? 5 : 2} className="py-8 font-black text-xl text-emerald-600 dark:text-emerald-400 uppercase tracking-tighter">الإيرادات التشغيلية</td></tr>
                {mappedAccounts.filter(a => a.type === AccountType.INCOME).map(a => (
                  <tr key={a.id} className="text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800/30 transition">
                    <td className="py-4 px-2 font-bold">{a.name}</td>
                    <td className="py-4 px-2 text-left font-black">{a.current.toLocaleString()}</td>
                    {isCompareMode && (
                      <>
                        <td className="py-4 px-2 text-left text-slate-400 font-mono">{a.previous.toLocaleString()}</td>
                        <td className={`py-4 px-2 text-left font-black ${a.diff >= 0 ? 'text-emerald-500' : 'text-rose-500'}`}>{a.diff > 0 ? '+' : ''}{a.diff.toLocaleString()}</td>
                        <td className={`py-4 px-2 text-left font-black ${a.percent >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
                          {a.percent !== 0 ? (a.percent > 0 ? '↑' : '↓') : ''} {Math.abs(a.percent).toFixed(1)}%
                        </td>
                      </>
                    )}
                  </tr>
                ))}
                <tr className="bg-slate-900 text-white font-black">
                  <td className="py-5 px-4 rounded-r-2xl">إجمالي الإيرادات</td>
                  <td className="py-5 px-2 text-left">{totalIncomeCurrent.toLocaleString()}</td>
                  {isCompareMode && (
                    <>
                      <td className="py-5 px-2 text-left">{totalIncomePrev.toLocaleString()}</td>
                      <td className={`py-5 px-2 text-left ${incomeStats.diff >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>{incomeStats.diff > 0 ? '+' : ''}{incomeStats.diff.toLocaleString()}</td>
                      <td className="py-5 px-4 text-left rounded-l-2xl">{incomeStats.percent.toFixed(1)}%</td>
                    </>
                  )}
                </tr>

                {/* Gross Profit Calc */}
                <tr className="text-rose-600 dark:text-rose-400 font-bold italic">
                  <td className="py-4 px-2">يخصم: تكلفة البضاعة المباعة (COGS)</td>
                  <td className="py-4 px-2 text-left">({totalCogsCurrent.toLocaleString()})</td>
                  {isCompareMode && <td colSpan={3}></td>}
                </tr>
                <tr className="border-y-4 border-slate-900 dark:border-slate-700 font-black text-2xl text-slate-800 dark:text-white">
                  <td className="py-6 px-2">مجمل الربح (Gross Profit)</td>
                  <td className="py-6 px-2 text-left">{grossProfitCurrent.toLocaleString()}</td>
                  {isCompareMode && (
                    <>
                      <td className="py-6 px-2 text-left text-slate-400">{grossProfitPrev.toLocaleString()}</td>
                      <td className="py-6 px-2 text-left" colSpan={2}>
                         <span className={`px-3 py-1 rounded-lg text-sm ${grossProfitStats.diff >= 0 ? 'bg-emerald-500 text-white' : 'bg-rose-500 text-white'}`}>
                            {grossProfitStats.percent.toFixed(1)}% {grossProfitStats.percent > 0 ? 'نمو' : 'تراجع'}
                         </span>
                      </td>
                    </>
                  )}
                </tr>

                {/* Expenses Section */}
                <tr><td colSpan={isCompareMode ? 5 : 2} className="py-8 font-black text-xl text-rose-600 dark:text-rose-400">المصاريف التشغيلية والإدارية</td></tr>
                {otherExpenses.map(a => (
                  <tr key={a.id} className="text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/30 transition">
                    <td className="py-4 px-2 font-medium">{a.name}</td>
                    <td className="py-4 px-2 text-left font-bold">{a.current.toLocaleString()}</td>
                    {isCompareMode && (
                      <>
                        <td className="py-4 px-2 text-left opacity-40">{a.previous.toLocaleString()}</td>
                        <td className={`py-4 px-2 text-left font-bold ${a.diff > 0 ? 'text-rose-500' : 'text-emerald-500'}`}>{a.diff > 0 ? '+' : ''}{a.diff.toLocaleString()}</td>
                        <td className={`py-4 px-2 text-left font-bold ${a.diff > 0 ? 'text-rose-600' : 'text-emerald-600'}`}>
                           {a.diff > 0 ? '↑' : '↓'} {Math.abs(a.percent).toFixed(1)}%
                        </td>
                      </>
                    )}
                  </tr>
                ))}
                
                <tr className="bg-rose-50 dark:bg-rose-900/10 font-black">
                  <td className="py-5 px-4 rounded-r-2xl text-rose-800 dark:text-rose-400">إجمالي المصاريف</td>
                  <td className="py-5 px-2 text-left text-rose-600">({totalExpCurrent.toLocaleString()})</td>
                  {isCompareMode && (
                    <>
                      <td className="py-5 px-2 text-left opacity-60">({totalExpPrev.toLocaleString()})</td>
                      <td colSpan={2} className="py-5 px-4 text-left rounded-l-2xl text-xs font-bold text-slate-400 uppercase">معدل التغير: {expStats.percent.toFixed(1)}%</td>
                    </>
                  )}
                </tr>

                {/* Final Net Profit */}
                <tr><td colSpan={isCompareMode ? 5 : 2} className="py-12"></td></tr>
                <tr className={`text-white font-black text-3xl shadow-2xl transition-all ${netProfitCurrent >= 0 ? 'bg-emerald-600' : 'bg-rose-600'}`}>
                  <td className="py-8 px-10 rounded-r-[2rem]">صافي الربح / (الخسارة)</td>
                  <td className="py-8 px-2 text-left">{netProfitCurrent.toLocaleString()} <span className="text-sm opacity-60">{currencySymbol}</span></td>
                  {isCompareMode && (
                    <>
                      <td className="py-8 px-2 text-left opacity-50">{netProfitPrev.toLocaleString()}</td>
                      <td className="py-8 px-10 text-left rounded-l-[2rem] text-sm" colSpan={2}>
                        {netProfitStats.percent > 0 ? 'زيادة سنوية 📈' : 'انخفاض سنوي 📉'}
                        <br />
                        بنسبة {Math.abs(netProfitStats.percent).toFixed(1)}%
                      </td>
                    </>
                  )}
                </tr>
              </tbody>
            </table>
          </div>

          <div className="mt-16 text-[10px] text-slate-400 font-black text-center uppercase tracking-[0.3em] border-t-2 dark:border-slate-800 pt-10">
            CONFIDENTIAL FINANCIAL REPORT • GENERATED BY SMART ACCOUNTANT AI • {new Date().toLocaleDateString('ar-EG')}
          </div>
        </div>
      </div>
    );
  };

  const renderBalanceSheet = () => {
    const assets = accounts.filter(a => a.type === AccountType.ASSET);
    const liabilities = accounts.filter(a => a.type === AccountType.LIABILITY);
    const equity = accounts.filter(a => a.type === AccountType.EQUITY);
    const totalAssets = assets.reduce((s, a) => s + a.balance, 0);
    const totalLiabilities = liabilities.reduce((s, a) => s + a.balance, 0);
    const totalEquity = equity.reduce((s, a) => s + a.balance, 0);

    return (
      <div className="space-y-6">
        <div className="flex justify-end print:hidden">
          <button onClick={handlePrint} className="bg-slate-900 dark:bg-emerald-600 text-white px-8 py-3 rounded-2xl font-black shadow-xl flex items-center gap-3"><span>📄</span> طباعة المركز المالي</button>
        </div>
        <div className="bg-white dark:bg-slate-900 p-8 lg:p-16 rounded-[3rem] shadow-sm border border-slate-100 dark:border-slate-800 max-w-5xl mx-auto print:bg-white print:text-black">
          <div className="text-center mb-16 border-b-2 dark:border-slate-800 pb-10">
            <h4 className="text-emerald-600 font-black text-lg mb-2">{companyName}</h4>
            <h2 className="text-4xl font-black text-slate-800 dark:text-white">قائمة المركز المالي</h2>
            <p className="text-slate-400 font-bold mt-2 uppercase tracking-widest">Balance Sheet - As of {new Date().toLocaleDateString('ar-EG')}</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-20 print:gap-10">
            <div className="space-y-8">
              <h4 className="text-xl font-black text-emerald-600 dark:text-emerald-400 border-b-4 border-emerald-500 pb-3 flex justify-between">
                <span>الأصول</span>
                <span>Assets</span>
              </h4>
              <div className="space-y-4">
                {assets.map(a => (
                  <div key={a.id} className="flex justify-between items-center py-3 border-b border-slate-50 dark:border-slate-800 text-slate-700 dark:text-slate-300">
                    <span className="font-bold">{a.name}</span>
                    <span className="font-black text-lg">{a.balance.toLocaleString()}</span>
                  </div>
                ))}
              </div>
              <div className="flex justify-between py-6 font-black text-2xl bg-emerald-600 text-white px-8 rounded-3xl shadow-lg shadow-emerald-900/20">
                <span>إجمالي الأصول</span>
                <span>{totalAssets.toLocaleString()}</span>
              </div>
            </div>

            <div className="space-y-10">
              <div>
                <h4 className="text-xl font-black text-amber-600 dark:text-amber-400 border-b-4 border-amber-500 pb-3 flex justify-between mb-6">
                  <span>الالتزامات وحقوق الملكية</span>
                  <span>Liabilities & Equity</span>
                </h4>
                <div className="space-y-6">
                   <div>
                     <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3">الالتزامات (Liabilities)</p>
                     {liabilities.map(a => (
                       <div key={a.id} className="flex justify-between py-2 border-b border-slate-50 dark:border-slate-800 text-slate-700 dark:text-slate-300">
                         <span className="font-bold">{a.name}</span>
                         <span className="font-black">{a.balance.toLocaleString()}</span>
                       </div>
                     ))}
                   </div>
                   <div>
                     <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3">حقوق الملكية (Equity)</p>
                     {equity.map(a => (
                       <div key={a.id} className="flex justify-between py-2 border-b border-slate-50 dark:border-slate-800 text-slate-700 dark:text-slate-300">
                         <span className="font-bold">{a.name}</span>
                         <span className="font-black">{a.balance.toLocaleString()}</span>
                       </div>
                     ))}
                   </div>
                </div>
              </div>
              <div className="flex justify-between py-6 font-black text-2xl bg-slate-900 text-white px-8 rounded-3xl shadow-lg">
                <span>إجمالي الخصوم والملكبة</span>
                <span>{(totalLiabilities + totalEquity).toLocaleString()}</span>
              </div>
            </div>
          </div>
          
          <div className={`mt-16 p-6 rounded-[2rem] text-center font-black transition-all ${Math.abs(totalAssets - (totalLiabilities + totalEquity)) < 0.01 ? 'bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600' : 'bg-rose-50 dark:bg-rose-900/20 text-rose-600 animate-pulse border-2 border-rose-500/20'}`}>
            {Math.abs(totalAssets - (totalLiabilities + totalEquity)) < 0.01 ? '✓ ميزانية متزنة - جميع الحسابات مطابقة' : '⚠ تنبيه: يوجد عدم اتزان في الميزانية!'}
          </div>
        </div>
      </div>
    );
  };

  const renderInventoryReport = () => {
    const categories = Array.from(new Set(inventory.map(i => i.category || 'عام')));
    const filteredInventory = inventory.filter(i => inventoryCategory === 'الكل' || i.category === inventoryCategory);
    const totalInventoryValue = inventory.reduce((sum, item) => sum + (item.quantity * item.unitPrice), 0);

    return (
      <div className="space-y-8 animate-in fade-in slide-in-from-top-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 print:grid-cols-1">
          <div className="bg-emerald-600 p-8 rounded-[2rem] text-white shadow-xl">
            <p className="text-emerald-200 text-xs font-black uppercase tracking-widest mb-2">القيمة الإجمالية للمخزون</p>
            <p className="text-4xl font-black">{totalInventoryValue.toLocaleString()} <span className="text-sm opacity-60">{currencySymbol}</span></p>
          </div>
          <div className="bg-slate-100 dark:bg-slate-900 p-8 rounded-[2rem] border border-slate-200 dark:border-slate-800">
            <p className="text-slate-400 text-xs font-black uppercase tracking-widest mb-2">عدد المنتجات المسجلة</p>
            <p className="text-4xl font-black text-slate-800 dark:text-white">{inventory.length}</p>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-6 rounded-[2rem] shadow-sm border border-slate-100 dark:border-slate-800 flex flex-wrap gap-4 items-center justify-between print:hidden">
          <div className="flex items-center gap-4">
            <label className="text-xs font-black text-slate-400 uppercase tracking-widest">تصفية حسب الفئة:</label>
            <select 
              className="px-6 py-3 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl text-sm font-bold outline-none focus:ring-2 focus:ring-emerald-500"
              value={inventoryCategory}
              onChange={e => setInventoryCategory(e.target.value)}
            >
              <option value="الكل">جميع التصنيفات</option>
              {categories.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
          <button onClick={handlePrint} className="bg-slate-900 text-white px-8 py-3 rounded-2xl font-black shadow-lg">📄 طباعة الجرد</button>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-[2.5rem] shadow-sm border border-slate-100 dark:border-slate-800 overflow-hidden print:border-none">
          <table className="w-full text-right">
            <thead className="bg-slate-50 dark:bg-slate-950 text-slate-400 text-[10px] font-black uppercase tracking-widest border-b border-slate-100 dark:border-slate-800">
              <tr>
                <th className="px-8 py-6">المنتج</th>
                <th className="px-8 py-6">الكمية</th>
                <th className="px-8 py-6">التكلفة</th>
                <th className="px-8 py-6 text-left">قيمة المخزون</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50 dark:divide-slate-800">
              {filteredInventory.map(item => (
                <tr key={item.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/30 transition text-slate-800 dark:text-slate-200">
                  <td className="px-8 py-5 font-black text-lg">{item.name}</td>
                  <td className="px-8 py-5 font-mono font-bold text-slate-500">{item.quantity}</td>
                  <td className="px-8 py-5 text-slate-400 font-bold">{item.unitPrice.toLocaleString()}</td>
                  <td className="px-8 py-5 text-left font-black text-emerald-600 dark:text-emerald-400">{(item.quantity * item.unitPrice).toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  };

  const renderContent = () => {
    switch (type) {
      case 'income': return renderIncomeStatement();
      case 'balance': return renderBalanceSheet();
      case 'inventory': return renderInventoryReport();
      default: return null;
    }
  };

  return <div className="animate-in fade-in duration-500">{renderContent()}</div>;
};

export default Reports;
