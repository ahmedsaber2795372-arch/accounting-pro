
import React, { useState, useEffect } from 'react';
import { AppSettings } from '../types';
import { TRANSLATIONS } from '../constants';

interface SettingsProps {
  settings: AppSettings;
  onUpdate: (settings: AppSettings) => void;
}

const Settings: React.FC<SettingsProps> = ({ settings, onUpdate }) => {
  const t = TRANSLATIONS[settings.language];
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);

  useEffect(() => {
    window.addEventListener('beforeinstallprompt', (e) => {
      e.preventDefault();
      setDeferredPrompt(e);
    });
  }, []);

  const handleInstallClick = async () => {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') setDeferredPrompt(null);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 lg:space-y-10 animate-in fade-in slide-in-from-bottom-4 duration-500">
      {/* الإعدادات الأساسية */}
      <div className="bg-white dark:bg-slate-900 p-6 lg:p-12 rounded-[2.5rem] shadow-sm border border-slate-100 dark:border-slate-800">
        <h3 className="text-2xl lg:text-3xl font-black text-slate-800 dark:text-white mb-10 border-b dark:border-slate-800 pb-6 flex items-center gap-3">
          <span>⚙️</span> {t.settings}
        </h3>

        <div className="grid grid-cols-1 gap-8">
          <div className="space-y-3">
            <label className="block text-xs font-black text-slate-400 uppercase tracking-widest">{t.companyNameLabel}</label>
            <input
              type="text"
              className="w-full px-5 py-4 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl outline-none text-slate-800 dark:text-white font-bold"
              value={settings.companyName}
              onChange={(e) => onUpdate({ ...settings, companyName: e.target.value })}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="space-y-3">
              <label className="block text-xs font-black text-slate-400 uppercase tracking-widest">{t.languageLabel}</label>
              <select className="w-full px-5 py-4 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl font-bold" value={settings.language} onChange={(e) => onUpdate({ ...settings, language: e.target.value as 'ar' | 'en' })}>
                <option value="ar">العربية (AR)</option>
                <option value="en">English (EN)</option>
              </select>
            </div>
            <div className="space-y-3">
              <label className="block text-xs font-black text-slate-400 uppercase tracking-widest">{t.themeLabel}</label>
              <select className="w-full px-5 py-4 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl font-bold" value={settings.theme} onChange={(e) => onUpdate({ ...settings, theme: e.target.value as 'light' | 'dark' })}>
                <option value="light">{t.light}</option>
                <option value="dark">{t.dark}</option>
              </select>
            </div>
            <div className="space-y-3">
              <label className="block text-xs font-black text-slate-400 uppercase tracking-widest">{t.currencyLabel}</label>
              <select className="w-full px-5 py-4 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl font-bold" value={settings.currency} onChange={(e) => onUpdate({ ...settings, currency: e.target.value as 'SAR' | 'EGP' })}>
                <option value="SAR">SAR</option>
                <option value="EGP">EGP</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* الحالة والحفظ */}
      <div className="bg-emerald-950 p-8 lg:p-12 rounded-[2.5rem] text-white shadow-2xl relative overflow-hidden">
        <div className="relative z-10">
          <h3 className="text-xl lg:text-2xl font-black mb-6 flex items-center gap-3 text-emerald-400">
            <span>✅</span> البرنامج الآن مربوط بـ GitHub
          </h3>
          <p className="text-slate-400 text-sm mb-8 leading-relaxed">
            بما أنك رفعت الملفات، سيقوم GitHub الآن ببناء البرنامج. يمكنك الوصول إليه دائماً عبر الرابط التالي:
          </p>
          <div className="bg-slate-900 p-4 rounded-xl font-mono text-emerald-400 text-xs border border-emerald-500/20 mb-6">
            https://ahmedsaber2795372-arch.github.io/Ahmed-Saber/
          </div>
          <button 
            onClick={handleInstallClick} 
            disabled={!deferredPrompt}
            className="bg-emerald-500 text-white px-10 py-4 rounded-2xl font-black text-sm hover:bg-emerald-600 transition disabled:opacity-30 flex items-center gap-3 shadow-xl"
          >
            <span>💻</span> تثبيت البرنامج كأيقونة على اللابتوب
          </button>
        </div>
      </div>
    </div>
  );
};

export default Settings;
